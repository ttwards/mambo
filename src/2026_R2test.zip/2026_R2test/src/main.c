#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <zephyr/device.h>
#include <zephyr/logging/log.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/motor.h>
#include <zephyr/drivers/sbus.h>
#include <zephyr/drivers/chassis.h>
#include <ares/board/init.h>
#include <ares/ekf/imu_task.h>
#include <ares/interface/usb/usb_bulk.h>
#include <ares/protocol/dual/dual_protocol.h>
#include <ares/ares_comm.h>
#include <sys/_stdint.h>
#include "devices.h"
#include "zephyr/drivers/gpio.h"
#include <arm_math.h>

LOG_MODULE_REGISTER(main, LOG_LEVEL_DBG);
#define deg2high(deg)  ((deg)*3.14159f * 45.0f / 360.0f)
#define high2deg(high) ((high)*360.0f / (3.14159f * 45.0f))

DUAL_PROPOSE_PROTOCOL_DEFINE(dual_protocol);
ARES_BULK_INTERFACE_DEFINE(usb_bulk_interface);

#define CHASSIS_SRC_SBUS
sync_table_t *angle_tx;

float action[4] = {0};
float angle[12] = {0};
uint8_t actionbuf[16] = {0};
uint8_t anglebuf[48] = {0};

static struct gpio_callback sensor1_cb_data;
static struct gpio_callback sensor2_cb_data;
static struct gpio_callback sensor3_cb_data;
static struct gpio_callback sensor4_cb_data;

void unified_sensor_callback(const struct device *port, struct gpio_callback *cb, uint32_t pins)
{
	if (port == sensor1.port && (pins & BIT(sensor1.pin))) {
		if (gpio_pin_get_dt(&sensor1) > 0) {
			angle[0] = 1.0f;
		} else {
			angle[0] = 0.0f;
		}
	}

	if (port == sensor2.port && (pins & BIT(sensor2.pin))) {
		if (gpio_pin_get_dt(&sensor2) > 0) {
			angle[1] = 1.0f;
		} else {
			angle[1] = 0.0f;
		}
	}

	if (port == sensor3.port && (pins & BIT(sensor3.pin))) {
		if (gpio_pin_get_dt(&sensor3) > 0) {
			angle[2] = 1.0f;
		} else {
			angle[2] = 0.0f;
		}
	}

	if (port == sensor4.port && (pins & BIT(sensor4.pin))) {
		if (gpio_pin_get_dt(&sensor4) > 0) {
			angle[3] = 1.0f;
		} else {
			angle[3] = 0.0f;
		}
	}
}

int rank[4] = {1, 1, -1, -1};
bool ups[4] = {true, true, true, true};
const struct device *dmmotor[4];
void run()
{
	for (int id = 0; id < 4; id++) {
		motor_set_mit(dmmotor[id], 10.0f, -30.0f * rank[id], 0.0);
		ups[id] = true;
		k_sleep(K_USEC(130));
	}
}
void lift(int id, bool up)
{
	if (up && (!ups[id])) {
		motor_set_mit(dmmotor[id], 10.0f, 0.0f * rank[id], 0.0);
		ups[id] = true;
	} else if ((!up) && (ups[id])) {
		motor_set_mit(dmmotor[id], 10.0f, -510.0f * rank[id], 0.0);
		ups[id] = false;
	}
	k_sleep(K_USEC(130));
}
void lifthigh(int id, float high)
{
	if (high > 400.0f) {
		high = 400.0f;
	} else if (high < 0.0f) {
		high = 0.0f;
	}
	if (dmmotor[id] != NULL) {
		motor_set_mit(dmmotor[id], 10.0f, -1.0f * rank[id] * (float)high2deg(high), 0.0f);
	}

	k_sleep(K_USEC(130));
}
int cnt = 0;
void console_feedback(void *arg1, void *arg2, void *arg3)
{

	bool zeroed = false;
	float X = 0.0f, Y = 0.0f, angvel = 0.0f;
	while (1) {
		k_msleep(5);

		lifthigh(0, action[0]);
		lifthigh(1, action[1]);
		lifthigh(2, action[2]);
		lifthigh(3, action[3]);

#ifdef CHASSIS_SRC_SBUS
		angvel = -sbus_get_percent(sbus, 0);
		X = -sbus_get_percent(sbus, 3);
		Y = -sbus_get_percent(sbus, 1);
		
		angle[11]=sbus_get_percent(sbus, 4);
		float linear_magnitude = sqrtf(X * X + Y * Y);
		bool in_deadzone = ((linear_magnitude < 0.06f) && (fabsf(angvel) < 0.06f));
		if (linear_magnitude < 0.06f) {
			X = 0;
			Y = 0;
		}
		if (in_deadzone) {
			chassis_set_static(chassis, true);
			zeroed = true;
		} else {
			chassis_set_static(chassis, false);
			chassis_set_speed(chassis, -X, Y);
			chassis_set_gyro(chassis, angvel * 10.0f);
			angle[8] = X;
			angle[9] = Y;
			angle[10] = angvel * 10.0f;
			zeroed = false;
		}
#endif
		if (cnt++ % 500 == 0) {
			LOG_INF("block: %.1f, %.1f, %.1f, %.1f", (double)angle[0], (double)angle[1],
				(double)angle[2], (double)angle[3]);
			LOG_INF("high: %.1f, %.1f, %.1f, %.1f", (double)angle[4], (double)angle[5],
				(double)angle[6], (double)angle[7]);
			LOG_INF("X=%.1f Y=%.1f Gyro=%.1f, %.1f", (double)X, (double)Y,
				(double)(angvel * 10.0f), (double)angle[11]);
			LOG_INF("target_high: %.2f, %.2f, %.2f, %.2f", (double)action[0],
				(double)action[1], (double)action[2], (double)action[3]);
			
		}
	}
}

K_THREAD_DEFINE(feedback_thread, 4096, console_feedback, NULL, NULL, NULL, 2, 0, 100);
uint32_t log_cnt;

int action_rx_cb(int status)
{

	if (status == SYNC_PACK_STATUS_DONE) {
		memcpy(action, actionbuf, sizeof(action));
	}
	return 0;
}
void prepare()
{
	dmmotor[0] = dm_motor1;
	dmmotor[1] = dm_motor2;
	dmmotor[2] = dm_motor3;
	dmmotor[3] = dm_motor4;
	motor_control(dm_motor1, ENABLE_MOTOR);
	motor_control(dm_motor2, ENABLE_MOTOR);
	motor_control(dm_motor3, ENABLE_MOTOR);
	motor_control(dm_motor4, ENABLE_MOTOR);
	motor_set_mode(dm_motor1, MIT);
	motor_set_mode(dm_motor2, MIT);
	motor_set_mode(dm_motor3, MIT);
	motor_set_mode(dm_motor4, MIT);
	motor_control(wheel_motor1, ENABLE_MOTOR);
	motor_control(wheel_motor2, ENABLE_MOTOR);
	motor_control(wheel_motor3, ENABLE_MOTOR);
	motor_control(wheel_motor4, ENABLE_MOTOR);
	motor_set_mode(wheel_motor1, ML_SPEED);
	motor_set_mode(wheel_motor2, ML_SPEED);
	motor_set_mode(wheel_motor3, ML_SPEED);
	motor_set_mode(wheel_motor4, ML_SPEED);
	motor_control(steer_motor1, ENABLE_MOTOR);
	motor_control(steer_motor2, ENABLE_MOTOR);
	motor_control(steer_motor3, ENABLE_MOTOR);
	motor_control(steer_motor4, ENABLE_MOTOR);
	gpio_pin_configure_dt(&sensor1, GPIO_INPUT);
	gpio_pin_configure_dt(&sensor2, GPIO_INPUT);
	gpio_pin_configure_dt(&sensor3, GPIO_INPUT);
	gpio_pin_configure_dt(&sensor4, GPIO_INPUT);
	gpio_pin_interrupt_configure_dt(&sensor1, GPIO_INT_EDGE_BOTH);
	gpio_pin_interrupt_configure_dt(&sensor2, GPIO_INT_EDGE_BOTH);
	gpio_pin_interrupt_configure_dt(&sensor3, GPIO_INT_EDGE_BOTH);
	gpio_pin_interrupt_configure_dt(&sensor4, GPIO_INT_EDGE_BOTH);
	gpio_init_callback(&sensor1_cb_data, unified_sensor_callback, BIT(sensor1.pin));
	gpio_init_callback(&sensor2_cb_data, unified_sensor_callback, BIT(sensor2.pin));
	gpio_init_callback(&sensor3_cb_data, unified_sensor_callback, BIT(sensor3.pin));
	gpio_init_callback(&sensor4_cb_data, unified_sensor_callback, BIT(sensor4.pin));
	gpio_add_callback(sensor1.port, &sensor1_cb_data);
	gpio_add_callback(sensor2.port, &sensor2_cb_data);
	gpio_add_callback(sensor3.port, &sensor3_cb_data);
	gpio_add_callback(sensor4.port, &sensor4_cb_data);
	angle[0] = gpio_pin_get_dt(&sensor1) > 0 ? 1.0f : 0.0f;
	angle[1] = gpio_pin_get_dt(&sensor2) > 0 ? 1.0f : 0.0f;
	angle[2] = gpio_pin_get_dt(&sensor3) > 0 ? 1.0f : 0.0f;
	angle[3] = gpio_pin_get_dt(&sensor4) > 0 ? 1.0f : 0.0f;
}
int main(void)
{
	k_msleep(100);
	prepare();

	run();
	chassis_set_enabled(chassis, true);
	chassis_set_gyro(chassis, 0);

	ares_bind_interface(&usb_bulk_interface, &dual_protocol);
	dual_sync_add(&dual_protocol, 0x0101, actionbuf, 16, (dual_trans_cb_t)action_rx_cb);
	angle_tx = dual_sync_add(&dual_protocol, 0x0201, anglebuf, 48, NULL);

	while (1) {
		k_msleep(10);
		for (int i = 0; i < 4; i++) {
			if(rank[i] == 1) {
				angle[i + 4] = -1.0f * deg2high((float)motor_get_angle(dmmotor[i]));
			} else {
				angle[i + 4] = 900.0f + deg2high((float)motor_get_angle(dmmotor[i]));
			}
		}
		memcpy(anglebuf, angle, sizeof(angle));
		dual_sync_flush(&dual_protocol, angle_tx);
	}

	return 0;
}
